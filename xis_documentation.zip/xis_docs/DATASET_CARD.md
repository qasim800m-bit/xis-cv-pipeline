# Dataset Card

---

## 1. Object

**Standard Credit Card (ISO/IEC 7810 ID-1)**

| Property | Value |
|---|---|
| Object class name | `credit_card` |
| Real-world width | 85.6 mm |
| Real-world height | 54.0 mm |
| Thickness | 0.76 mm |
| Standard | ISO/IEC 7810 ID-1 |
| Corners | Rounded (radius ~3.18 mm) |

### Justification for Object Selection

The credit card was selected for the following reasons:

- **Standardised dimensions:** The ISO/IEC 7810 ID-1 standard defines exact dimensions universally, providing perfect ground-truth for metric accuracy validation without any measurement ambiguity.
- **Clear boundary:** The sharp rectangular outline with consistently coloured edges is straightforward to segment using polygon masks.
- **Universal availability:** Credit cards are available to every candidate for data collection.
- **Flat geometry:** Being a flat, non-deforming rigid object means no shape variation between instances — ideal for a measurement pipeline.
- **Scale reference:** The known dimensions make the credit card itself serve as the reference object for pixel-to-mm conversion, meaning no separate reference object is needed.

---

## 2. Collection Strategy

### 2.1 Camera Setup

All images were captured using a single fixed camera — the same camera used for intrinsic calibration — to ensure the calibration parameters are valid for all collected images.

**Important:** Images were captured before labelling, and all images were undistorted using the calibration parameters before the labelling process began (`dataset/undistort_dataset.py`). This ensures that the annotated coordinates correspond to the undistorted image space.

### 2.2 Variation Strategy

Images were deliberately captured with high variation across the following dimensions to improve model generalisation:

| Variation Axis | Details |
|---|---|
| Background | White table, dark wood, textured fabric, tiled floor, notebook paper, outdoor surface |
| Lighting | Bright natural (window), indoor tungsten lamp, fluorescent overhead, mixed, low-light |
| Angle | Top-down (0°), slight tilt (~15°), medium tilt (~30°), edge-on (~45°) |
| Rotation | 0°, 45°, 90°, 180° card rotation in the plane |
| Distance | 20 cm, 30 cm, 40 cm, 60 cm, 80 cm from camera |
| Occlusion | Fully visible, partially occluded by paper or hand |
| Scale | Small (card fills ~10% of frame), medium (~30%), large (~60%) |

### 2.3 Equipment

| Item | Details |
|---|---|
| Camera | Same device used for calibration |
| Capture mode | Manual focus, fixed white balance where possible |
| Image resolution | Native camera resolution |
| Format | JPEG |

---

## 3. Labelling

### 3.1 Tool

**Roboflow** (web-based annotation platform) — [roboflow.com](https://roboflow.com)

Roboflow was chosen because:
- It supports polygon segmentation annotation natively
- It exports directly to COCO JSON format (required by Detectron2)
- It provides automatic dataset splitting and augmentation previews
- The free tier is sufficient for datasets of this size

### 3.2 Annotation Type

**Polygon segmentation masks** — each annotation traces the exact outline of the visible credit card boundary. This produces a precise per-pixel mask rather than an approximate rectangular bounding box.

### 3.3 Labelling Protocol

1. Open each image in the Roboflow annotation editor
2. Use the **Smart Polygon** tool (AI-assisted) as a starting point where available
3. Manually refine vertices to precisely trace the card boundary
4. Ensure corners are correctly placed even at the rounded card corners
5. Apply the single class label: `credit_card`
6. Mark any occluded instances with a partial polygon covering only the visible region

### 3.4 Quality Control

- Each image was reviewed after annotation to ensure mask accuracy
- Images with severe motion blur or cards nearly fully occluded were discarded
- Annotations were checked to confirm the polygon closely follows the actual card boundary

---

## 4. Dataset Statistics

### 4.1 Splits

| Split | Images | Annotations | Percentage |
|---|---|---|---|
| Train | ~56 | ~56 | 70% |
| Validation | ~16 | ~16 | 20% |
| Test | ~8 | ~8 | 10% |
| **Total** | **~80** | **~80** | 100% |

> Exact counts are populated when `dataset/register_dataset.py` is run, which reads the actual COCO JSON files and generates `docs/DATASET_CARD.md` with the live statistics.

### 4.2 Class Distribution

| Class | Count | Percentage |
|---|---|---|
| `credit_card` | All instances | 100% |

This is a single-class dataset. All annotations belong to the `credit_card` class.

### 4.3 Image Statistics

| Metric | Value |
|---|---|
| Total images | ~80 |
| Minimum images per split | 8 (test) |
| Image format | JPEG |
| Annotation format | COCO JSON (polygon segmentation) |
| Instances per image | Typically 1, occasionally 2 |

---

## 5. Export Format

**COCO JSON — Instance Segmentation**

Each split folder contains:
- All image files (`.jpg`)
- `_annotations.coco.json` — COCO-format annotation file containing:
  - `images` — image metadata (id, filename, width, height)
  - `annotations` — per-instance annotations with `segmentation` polygon points, `bbox`, `area`, and `category_id`
  - `categories` — class list (`[{"id": 1, "name": "credit_card"}]`)

---

## 6. Preprocessing Applied

| Step | Details |
|---|---|
| Undistortion | All images undistorted with `cv2.undistort()` before use |
| Resize | None — images used at native resolution |
| Normalisation | Handled internally by Detectron2 during training |
| Augmentation (training only) | Random horizontal flip (p=0.5), multi-scale resize (shorter edge 640–800 px) — Detectron2 defaults |

---

## 7. Limitations

- Single class only — the model is not designed to detect or segment multiple object types simultaneously
- Dataset is captured with a single camera — model may not generalise to images from very different cameras
- Dataset size (~80 images) is modest; performance on highly unusual backgrounds or extreme angles may be lower
- Partial occlusion (>50% occluded) may cause missed detections
