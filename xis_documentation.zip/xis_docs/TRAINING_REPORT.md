# Model Training Report

---

## 1. Model Selection

### 1.1 Architecture

**Mask R-CNN** with a **ResNet-50 + FPN (Feature Pyramid Network)** backbone, implemented via the **Detectron2** framework.

Configuration string: `COCO-InstanceSegmentation/mask_rcnn_R_50_FPN_3x.yaml`

| Property | Value |
|---|---|
| Model family | Mask R-CNN |
| Backbone | ResNet-50 |
| Neck | Feature Pyramid Network (FPN) |
| Head | RoI Align + Mask Head |
| Framework | Detectron2 (Facebook AI Research) |
| Pretrained on | MS COCO (80 classes) |
| Fine-tuned on | Custom credit card dataset (1 class) |

### 1.2 Why Mask R-CNN — Selection Rationale

The assessment requires a model that is **not** a YOLO variant and **not** a Roboflow built-in model. Mask R-CNN satisfies both constraints and is additionally well-suited to this task for the following technical reasons:

**1. Per-pixel instance masks (not just bounding boxes)**
Mask R-CNN produces a binary segmentation mask for each detected object instance. This is essential for this pipeline — accurate mask boundaries allow more precise bounding box extraction than a direct box prediction, which directly improves measurement accuracy.

**2. Two-stage design for precision**
The Region Proposal Network (RPN) first proposes candidate object regions, and the second stage (RoI head) refines boxes and predicts masks. This two-stage approach produces more precise localisations than single-stage detectors, which is critical when the mask boundary determines the pixel-width used for mm conversion.

**3. Strong transfer learning from COCO**
ResNet-50 + FPN pretrained on 118,000 COCO images provides rich general feature representations. Fine-tuning on a small custom dataset (80 images) can achieve high accuracy because the backbone has already learned to detect edges, textures, and rectangular shapes relevant to credit cards.

**4. Well-documented and reproducible**
Detectron2 provides a deterministic training loop, config-file-based hyperparameters, and built-in COCO evaluation — making the training process fully reproducible and the metrics directly comparable to published baselines.

**Comparison with alternatives considered:**

| Model | Considered | Reason Not Selected |
|---|---|---|
| YOLOv8 / YOLO variants | Yes | Explicitly excluded by assessment |
| Roboflow built-in models | Yes | Explicitly excluded by assessment |
| SegFormer | Yes | Semantic segmentation (no instances); requires more data |
| SAM (Segment Anything) | Yes | Not a trainable detection model; requires prompts at inference |
| **Mask R-CNN** | **Selected** | Satisfies constraints; best fit for instance segmentation + measurement |

---

## 2. Training Configuration

### 2.1 Dataset Splits

| Split | Folder | Purpose |
|---|---|---|
| Train | `dataset/train_undistorted/` | Model parameter optimisation |
| Validation | `dataset/val_undistorted/` | Hyperparameter tuning, early stopping reference |
| Test | `dataset/test_undistorted/` | Final held-out evaluation (not used during training) |

All images were undistorted before training (see CALIBRATION_REPORT.md).

### 2.2 Hyperparameters

| Hyperparameter | Value | Rationale |
|---|---|---|
| Max iterations | 3,000 | Sufficient for fine-tuning on ~56 training images |
| Batch size (images per iteration) | 2 | Balances GPU memory usage with gradient stability |
| Base learning rate | 0.001 | Standard starting LR for fine-tuning Detectron2 models |
| LR warmup iterations | 200 | Prevents early instability with pretrained weights |
| LR decay steps | 2,000 and 2,640 | Cosine-like step decay at 66% and 88% of training |
| LR decay factor (gamma) | 0.1 | Standard reduction factor |
| ROI batch size per image | 128 | Detectron2 default |
| Checkpoint frequency | Every 500 iterations | Allows recovery from interruption |
| Evaluation frequency | Every 500 iterations | Tracks validation mAP during training |
| Number of classes | 1 | Single class: `credit_card` |

### 2.3 Augmentation Strategy

Detectron2 default augmentations applied during training:

| Augmentation | Details |
|---|---|
| Random horizontal flip | Probability = 0.5 |
| Multi-scale resize | Shorter edge randomly sampled from 640–800 px |

No additional custom augmentations were applied to avoid overfitting on the small dataset.

### 2.4 Pretrained Weights

The model was initialised from COCO pretrained weights:
`COCO-InstanceSegmentation/mask_rcnn_R_50_FPN_3x.yaml`

This is transfer learning — the backbone's feature extraction weights are carried over from COCO training, and only the classification and mask prediction heads are fine-tuned to the single `credit_card` class.

---

## 3. Training Metrics

### 3.1 Definitions

| Metric | Definition |
|---|---|
| mAP@0.5 | Mean Average Precision at IoU threshold 0.5 |
| mAP@0.5:0.95 | Mean Average Precision averaged over IoU thresholds 0.5 to 0.95 (step 0.05) |
| IoU | Intersection over Union — overlap between predicted and ground-truth mask |
| Precision | TP / (TP + FP) — fraction of detections that are correct |
| Recall | TP / (TP + FN) — fraction of ground-truth objects that were detected |
| F1 Score | 2 × (Precision × Recall) / (Precision + Recall) |

### 3.2 Test Set Results

> Exact numerical results are populated when `models/train.py` completes and evaluates on the test set. Results are also saved to `models/output/metrics.json`.

| Metric | BBox | Segmentation Mask |
|---|---|---|
| mAP@0.5:0.95 | (see metrics.json) | (see metrics.json) |
| mAP@0.5 | (see metrics.json) | (see metrics.json) |
| mAP@0.75 | (see metrics.json) | (see metrics.json) |
| AP (small) | (see metrics.json) | (see metrics.json) |
| AP (medium) | (see metrics.json) | (see metrics.json) |
| AP (large) | (see metrics.json) | (see metrics.json) |

**Interpretation guidance:**
- mAP@0.5 above 70% indicates strong detection performance for a single-class fine-tuned model
- mAP@0.5:0.95 above 50% indicates high mask quality (strict IoU thresholds)

### 3.3 Training Loss Curves

Loss curves (total loss vs. iteration, and validation mAP vs. iteration) are saved to:

`models/output/training_curves.png`

A well-trained model will show:
- Monotonically decreasing training loss
- Validation mAP increasing and stabilising before the end of training
- No large divergence between training and validation metrics (indicates no severe overfitting)

---

## 4. Inference Pipeline

The inference script (`inference/run_inference.py`) implements the following pipeline:

```
Input image path
      │
      ▼
  Load image (cv2.imread)
      │
      ▼
  Undistort (cv2.undistort with stored calibration)   ← MANDATORY
      │
      ▼
  Detectron2 DefaultPredictor (Mask R-CNN)
      │
      ├── pred_masks   → binary H×W mask per instance
      ├── pred_boxes   → bounding box per instance
      ├── scores       → confidence score per instance
      └── pred_classes → class index per instance
      │
      ▼
  Draw overlays (mask, contour, bounding box, label)
      │
      ▼
  Save annotated image to inference/outputs/
```

**Usage:**

```bash
# Single image:
python inference/run_inference.py --image path/to/image.jpg

# Batch:
python inference/run_inference.py --folder path/to/folder/

# With measurements:
python inference/run_inference.py --image path/to/image.jpg --measure
```

---

## 5. Saved Artefacts

| File | Contents |
|---|---|
| `models/output/model_final.pth` | Trained model weights |
| `models/output/config.yaml` | Complete Detectron2 training configuration |
| `models/output/metrics.json` | Per-iteration training and validation metrics |
| `models/output/training_curves.png` | Loss and mAP visualisation |
| `docs/TRAINING_REPORT.md` | This document (auto-generated summary also printed) |

---

## 6. Limitations

- Performance is bounded by dataset size (~80 images). More diverse training data would improve robustness to unusual backgrounds and extreme angles.
- The model is single-class and will not distinguish between multiple different objects.
- Inference assumes the camera used is the same calibrated camera. A different camera with different intrinsics would require recalibration.
- Very small instances (card occupying less than 5% of frame area) may be missed due to feature scale resolution.

---

## 7. References

- He, K., Gkioxari, G., Dollár, P., & Girshick, R. (2017). Mask R-CNN. *ICCV 2017*.
- Lin, T. Y., et al. (2017). Feature Pyramid Networks for Object Detection. *CVPR 2017*.
- Wu, Y., et al. (2019). Detectron2. Facebook AI Research. https://github.com/facebookresearch/detectron2
