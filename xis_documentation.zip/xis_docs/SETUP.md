# Setup & Installation Guide

---

## System Requirements

| Component | Minimum | Recommended |
|---|---|---|
| Operating System | Ubuntu 20.04 / Windows 10 / macOS 12 | Ubuntu 22.04 LTS |
| Python | 3.9 | 3.10 |
| RAM | 8 GB | 16 GB |
| Storage | 5 GB free | 20 GB free |
| GPU | None (CPU training is slow) | NVIDIA GPU with 6+ GB VRAM |
| CUDA | Not required | 11.8 or 12.1 |

---

## Step 1 — Clone the Repository

```bash
git clone https://github.com/YOUR_USERNAME/xis-cv-pipeline.git
cd xis-cv-pipeline
```

---

## Step 2 — Create a Virtual Environment

```bash
# Create environment
python -m venv venv

# Activate (Linux / macOS)
source venv/bin/activate

# Activate (Windows)
venv\Scripts\activate
```

---

## Step 3 — Install Python Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

---

## Step 4 — Install PyTorch

Choose the command that matches your system:

```bash
# CPU only (slower training, no GPU required):
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu

# NVIDIA GPU — CUDA 11.8:
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

# NVIDIA GPU — CUDA 12.1:
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
```

Verify PyTorch installed correctly:

```bash
python -c "import torch; print(torch.__version__); print('GPU:', torch.cuda.is_available())"
```

---

## Step 5 — Install Detectron2

```bash
pip install 'git+https://github.com/facebookresearch/detectron2.git'
```

Verify:

```bash
python -c "import detectron2; print(detectron2.__version__)"
```

**Windows users:** If the build fails, use WSL2 (Ubuntu on Windows) or try the prebuilt wheel from the [Detectron2 Windows guide](https://github.com/facebookresearch/detectron2/issues/9).

---

## Running the Pipeline — Step by Step

### Step 1A — Camera Calibration

1. Print a checkerboard pattern (search "opencv checkerboard 8x6 PDF") or display one on a monitor.
2. The default script expects **8 columns × 6 rows of inner corners**.
3. Take 20–30 photos of the checkerboard from varied angles and distances.
4. Place all photos inside `calibration/images/`.
5. If your checkerboard has different dimensions, edit these values at the top of `calibrate_camera.py`:

```python
CHECKERBOARD   = (8, 6)     # (columns-1, rows-1) inner corners
SQUARE_SIZE_MM = 25.0       # real size of one square in mm
```

6. Run:

```bash
python calibration/calibrate_camera.py
```

**Expected output:**
- `calibration/camera_matrix.npy`
- `calibration/dist_coeffs.npy`
- `calibration/calibration_params.json`
- `calibration/CALIBRATION_REPORT.md`
- `calibration/undistorted_samples/` — visual before/after comparison images

**Target:** Reprojection error below 0.5 px. Below 0.3 px is excellent.

---

### Step 1B — Collect and Label Dataset

1. Take 70+ photos of your chosen object (credit card) using the same camera.
2. Go to [roboflow.com](https://roboflow.com) — create a free account.
3. Create a new project → select **Instance Segmentation**.
4. Upload all your photos.
5. Use the polygon tool to draw a mask outline around the object in each image.
6. Apply the auto-split: 70% train / 20% val / 10% test.
7. Export → Format: **COCO JSON** → download and extract the ZIP.
8. Place the split folders into:

```
dataset/train/    ← images + _annotations.coco.json
dataset/val/      ← images + _annotations.coco.json
dataset/test/     ← images + _annotations.coco.json
```

---

### Step 1C — Undistort Dataset

```bash
python dataset/undistort_dataset.py
```

**Expected output:**
- `dataset/train_undistorted/`
- `dataset/val_undistorted/`
- `dataset/test_undistorted/`

Each folder contains undistorted images and a copy of the annotation JSON.

---

### Step 2A — Configure Training

Open `models/train.py` and verify these settings match your dataset:

```python
NUM_CLASSES    = 1        # number of object classes (1 = credit card only)
MAX_ITER       = 3000     # training iterations (increase to 5000 if mAP is low)
BATCH_SIZE     = 2        # reduce to 1 if you get CUDA out-of-memory error
LEARNING_RATE  = 0.001
CLASS_NAMES    = ["credit_card"]   # must match your Roboflow class name
```

Also update `CLASS_NAMES` in `inference/run_inference.py` and `demo.py` to match.

---

### Step 2B — Train the Model

```bash
python models/train.py
```

Training takes 30–120 minutes depending on your hardware. You will see loss values printed every few iterations — they should decrease over time.

**Expected output:**
- `models/output/model_final.pth` — trained model weights
- `models/output/metrics.json` — training metrics log
- `models/output/training_curves.png` — loss and mAP plots
- `docs/TRAINING_REPORT.md` — auto-generated report

---

### Step 2C — Test Inference

```bash
python inference/run_inference.py --image path/to/any_new_image.jpg
```

Check `inference/outputs/` for the annotated result. The model should draw a coloured mask around your object.

---

### Step 3A — End-to-End Demo

```bash
python demo.py --image path/to/your_image.jpg
```

**Expected output:**
```
[1] Image loaded ...
[2] Image undistorted ...
[3] Inference complete — 1 detection(s)
[4] pixels_per_mm = 428px / 85.6mm = 5.0000
[5] Measurements:
    Instance   Confidence   Width (mm)    Height (mm)
    0          0.962        85.3          53.8
[6] Output saved:
    demo_outputs/your_image_demo.jpg
    demo_outputs/your_image_demo.json
```

---

### Step 3B — Accuracy Validation

1. Physically measure 10+ instances of your object with a ruler or digital calliper.
2. Fill in `measurement/ground_truth.csv`:

```csv
image_path,gt_width_mm,gt_height_mm
dataset/test_undistorted/img_001.jpg,85.6,54.0
dataset/test_undistorted/img_002.jpg,85.5,54.0
...
```

3. Run:

```bash
python measurement/measure.py --validate --gt_csv measurement/ground_truth.csv
```

**Expected output:**
- Accuracy summary printed to terminal (MAE, MPE)
- `measurement/accuracy_report/accuracy_scatter.png`
- `measurement/accuracy_report/accuracy.json`
- `docs/MEASUREMENT_REPORT.md`

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `camera_matrix.npy not found` | Run `calibrate_camera.py` first |
| Reprojection error > 1.0 | Recapture calibration images with more angle variation and better lighting |
| `Detectron2 not installed` | Re-run the pip install from Step 5; ensure PyTorch is installed first |
| `model_final.pth not found` | Run `models/train.py` to completion |
| Nothing detected in inference | Lower `CONFIDENCE_THRESH` to 0.3 in `run_inference.py` |
| `CUDA out of memory` | Set `BATCH_SIZE = 1` in `models/train.py` |
| Low mAP (below 50%) | Add more diverse training images; increase `MAX_ITER` to 5000 |
| Inaccurate measurements | Ensure reference object is fully in frame and model detects it with high confidence |

---

## Docker (Optional)

For a fully reproducible environment:

```dockerfile
FROM pytorch/pytorch:2.0.1-cuda11.7-cudnn8-runtime

RUN pip install \
    opencv-python-headless \
    pycocotools \
    matplotlib \
    tqdm \
    pandas \
    'git+https://github.com/facebookresearch/detectron2.git'

WORKDIR /workspace
COPY . .
```

Build and run:

```bash
docker build -t xis-cv-pipeline .
docker run --gpus all -v $(pwd):/workspace xis-cv-pipeline python demo.py --image test.jpg
```
